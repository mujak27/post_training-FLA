package human;

import chat.Chat;

public abstract class Human {
	public Chat chat;

}
