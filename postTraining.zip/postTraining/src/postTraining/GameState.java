package postTraining;

public class GameState {
	static int money, score;

}
