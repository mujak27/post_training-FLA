package waiter;

import postTraining.Restaurant;

public class State5ServingFood extends WaiterState {

	public State5ServingFood(Waiter waiter) {
		super(waiter);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void activity() {
		try {			
			waiter.thread.sleep(1000);
		}catch (Exception e) {
			return;
		}
		if(waiter.chat == null) System.out.println(waiter.getName() + " chat null");
		else System.out.println(waiter.getName() + " chat not null");
		waiter.chat.startEating();
	}

	@Override
	public void changeState(String type) {
		waiter.state = new State1Idle(waiter);	
		Restaurant.getInstance().availWaiter(waiter);
	}

}
